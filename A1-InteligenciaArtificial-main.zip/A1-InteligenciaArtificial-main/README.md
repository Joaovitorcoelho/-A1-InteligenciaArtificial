# A1 - Inteligência Artificial 
Avaliação A1 da UC Inteligência Artificial - Unisociesc

Objetivo: Implementar o algoritimo A* que percore um grafo de cidades para achar o menor caminho entre qualquer cidade e a capital do estado. No caso o grafo utilizado é baseado no estado de Santa Catarina com algumas cidades.

OBS: Ao rodar o algoritimo as informações mais detalhadas sobre o caminho estarão no console do navegador. No Chrome basta pressionar as teclas CTRL+SHIFT+I e depois clicar em console. 

![grafo](https://user-images.githubusercontent.com/68485885/136716698-b6c0480a-add6-49f7-98d6-c1d4a09d945e.jpg)
![euclidiano](https://user-images.githubusercontent.com/68485885/136717290-93a6cba6-5ae6-40c1-a9fb-1b04e0c82ad7.jpg)
